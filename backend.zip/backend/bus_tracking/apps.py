from django.apps import AppConfig


class BusTrackingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bus_tracking'
